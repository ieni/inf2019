var hoogte = 150;

function setup() {
  canvas = createCanvas(450,300);
  canvas.parent('processing');
  background('gainsboro');
  noStroke();
  fill('silver');

}

function draw() {
  fill('plum');

  fill('mediumorchid');

}
