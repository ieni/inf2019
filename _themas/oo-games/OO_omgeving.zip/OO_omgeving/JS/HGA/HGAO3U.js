var hoogte = 150;

function setup() {
  var myCanvas = createCanvas(450,300);
  myCanvas.parent('processing');
  background('gainsboro');
  noStroke();
  fill('silver');

}

function draw() {
  fill('plum');

  fill('mediumorchid');

}
